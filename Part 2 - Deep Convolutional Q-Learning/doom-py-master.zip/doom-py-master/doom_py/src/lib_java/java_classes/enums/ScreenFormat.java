package vizdoom;
public enum ScreenFormat {
    CRCGCB,
    CRCGCBDB,
    RGB24,
    RGBA32,
    ARGB32,
    CBCGCR,
    CBCGCRDB,
    BGR24,
    BGRA32,
    ABGR32,
    GRAY8,
    DEPTH_BUFFER8,
    DOOM_256_COLORS8;
}
