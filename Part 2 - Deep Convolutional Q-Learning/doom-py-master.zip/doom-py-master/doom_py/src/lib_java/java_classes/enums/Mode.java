package vizdoom;
public enum Mode{
    PLAYER,
    SPECTATOR,
    ASYNC_PLAYER,
    ASYNC_SPECTATOR;
}

