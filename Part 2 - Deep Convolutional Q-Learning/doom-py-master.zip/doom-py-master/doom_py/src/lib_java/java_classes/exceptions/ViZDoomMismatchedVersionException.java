package vizdoom;
public class ViZDoomMismatchedVersionException extends Exception {
    public ViZDoomMismatchedVersionException(String message) {
        super(message);
    }
}
