package vizdoom;
public class MessageQueueException extends Exception {
    public MessageQueueException(String message) {
        super(message);
    }
}
