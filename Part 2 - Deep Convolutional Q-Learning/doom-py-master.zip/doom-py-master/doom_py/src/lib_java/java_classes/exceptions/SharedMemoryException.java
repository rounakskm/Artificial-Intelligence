package vizdoom;
public class SharedMemoryException extends Exception {
    public SharedMemoryException(String message) {
        super(message);
    }
}
