package vizdoom;
public class ViZDoomUnexpectedExitException extends Exception {
    public ViZDoomUnexpectedExitException(String message) {
        super(message);
    }
}
