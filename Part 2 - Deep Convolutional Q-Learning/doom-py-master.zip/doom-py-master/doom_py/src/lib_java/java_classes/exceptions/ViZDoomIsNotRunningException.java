package vizdoom;
public class ViZDoomIsNotRunningException extends Exception {
    public ViZDoomIsNotRunningException(String message) {
        super(message);
    }
}
