package vizdoom;
public class ViZDoomErrorException extends Exception {
    public ViZDoomErrorException(String message) {
        super(message);
    }
}
